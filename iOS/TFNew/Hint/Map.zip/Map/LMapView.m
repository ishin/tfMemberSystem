//
//  LMapView.m
//  CakeLove
//
//  Created by radar on 10-2-26.
//  Copyright 2010 RED/SAFI. All rights reserved.
//

#import "LMapView.h"


#define PI 3.1415926

@implementation LMapView

@synthesize delegate;
@synthesize _userMarker;
@synthesize _markerArray;
@synthesize needShowAccessView;
@synthesize _map;

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
		
		_map = [[MKMapView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
	    [_map setMapType: MKMapTypeStandard];
		[_map setDelegate:self];
		
		needShowAccessView = YES;
		
		[self addSubview:_map];
	
    }
    return self;
}


- (void)drawRect:(CGRect)rect {
    // Drawing code	
}



-(void)MoveMapToLocation:(double)latitude withLng:(double)longitude
{
	@try {
        CLLocationCoordinate2D theCenter;
        theCenter.latitude = latitude;
        theCenter.longitude = longitude;
        
        
        MKCoordinateSpan theSpan;
        theSpan.latitudeDelta = 0.05;
        theSpan.longitudeDelta = 0.05;
        
        MKCoordinateRegion theRegin;
        theRegin.center = theCenter;
        theRegin.span = theSpan;
        
        [_map setRegion:theRegin];
        [_map regionThatFits:theRegin];
        
        [_map setCenterCoordinate:theCenter animated:YES];
    }
    @catch (NSException *exception) {
        ;
    }
    @finally {
        ;
    }
}
-(void)MoveMapToLocationBySpan:(double)latitude withLng:(double)longitude bySpan:(MKCoordinateSpan)theSpan
{
	CLLocationCoordinate2D theCenter;
	theCenter.latitude = latitude; 
	theCenter.longitude = longitude;
	
	MKCoordinateRegion theRegin;
	theRegin.center=theCenter;
	theRegin.span = theSpan;
	
	
	[_map setRegion:theRegin];
	[_map regionThatFits:theRegin];
	
	[_map setCenterCoordinate:theCenter animated:YES];

}
-(void)MoveMapToLocationByDelta:(double)latitude withLng:(double)longitude delta:(double)delta
{
	CLLocationCoordinate2D theCenter;
	theCenter.latitude = latitude; 
	theCenter.longitude = longitude;
	
	
	MKCoordinateSpan theSpan;
	theSpan.latitudeDelta = delta;
	theSpan.longitudeDelta = delta;
	
	MKCoordinateRegion theRegin;
	theRegin.center=theCenter;
	theRegin.span = theSpan;
	
	
	
	//[_map setRegion:r];
	/*
	[_map setCenterCoordinate:theCenter animated:YES];
	
	MKCoordinateRegion r = [_map regionThatFits:theRegin];
	[_map setRegion:r];
	 */
	
	

	 [_map setRegion:theRegin];
	 [_map regionThatFits:theRegin];
	 
	 [_map setCenterCoordinate:theCenter animated:YES];
	 
}


- (void) updateCenter{
	[self MoveMapToLocationByDelta:_userMarker.latitude withLng:_userMarker.longitude delta:0.01];
	
	[_map selectAnnotation:_map.userLocation animated:YES];
}


- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation {
	
	if(annotation == mapView.userLocation)
	{
		mapView.userLocation.title = _userMarker.title;
		mapView.userLocation.subtitle = _userMarker.subtitle;
				
		if(mapView.userLocation.location){
			_userMarker.latitude = mapView.userLocation.location.coordinate.latitude;
			_userMarker.longitude = mapView.userLocation.location.coordinate.longitude;
			
			if(self.delegate && [self.delegate respondsToSelector:@selector(updateMyLocation:latitude:)]){
				[self.delegate updateMyLocation:_userMarker.longitude latitude:_userMarker.latitude];
			}
		}
		return nil;
	}
	else
	{
		Marker *marker = (Marker*)annotation;
		
		if(marker.annImage == nil)
		{
        
			MKPinAnnotationView *pinmarkerView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"pinmarker"];
			
			pinmarkerView.animatesDrop = YES;
			pinmarkerView.pinColor = marker.pinAnColor;
			pinmarkerView.canShowCallout = YES;
			
			UIButton *nextBtn = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
			pinmarkerView.rightCalloutAccessoryView = nextBtn;
			
			if(marker.leftImage != nil)
			{
				UIImageView *imageview = [[UIImageView alloc] initWithImage:marker.leftImage];
				pinmarkerView.leftCalloutAccessoryView = imageview;
			}
			
			if(!needShowAccessView){
				pinmarkerView.rightCalloutAccessoryView = nil;
			}
 
			return pinmarkerView;
		}
		else
		{
			MKAnnotationView *markerView=[[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"marker"];
			markerView.image = marker.annImage;
			markerView.canShowCallout = YES;
			
			UIButton *nextBtn = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
			markerView.rightCalloutAccessoryView = nextBtn;
			
			if(marker.leftImage != nil)
			{
				UIImageView *imageview = [[UIImageView alloc] initWithImage:marker.leftImage];
				markerView.leftCalloutAccessoryView = imageview;
			}
			
			if(!needShowAccessView){
				markerView.rightCalloutAccessoryView = nil;
			}
		
			return markerView;
		
		}
	}
	
}

- (void)mapView:(MKMapView *)mapView didAddAnnotationViews:(NSArray *)views
{
	if(views == nil) return;
	for(int i=0; i<[views count]; i++)
	{
		id view = [views objectAtIndex:i];
		if([[view class] isSubclassOfClass:[NSClassFromString(@"MKUserLocationView") class]])
		{
			MKAnnotationView *userLocationView = [mapView viewForAnnotation:mapView.userLocation];
			//UIButton *nBtn = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
			//userLocationView.rightCalloutAccessoryView = nBtn;
						
			if(_userMarker.leftImage != nil)
			{
				UIImageView *imageview = [[UIImageView alloc] initWithImage:_userMarker.leftImage];
				userLocationView.leftCalloutAccessoryView = imageview;
				
			}
			
			[self performSelectorOnMainThread:@selector(updateCenter) withObject:nil waitUntilDone:NO];
			
			break;
		}
		
	}
}

- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control
{
	Marker *marker = (Marker*)view.annotation;
	if(self.delegate &&[(NSObject*)self.delegate respondsToSelector:@selector(RetuenAnnotationCalloutAccessoryTapFromMapView:withMarker:)])
	{
		[self.delegate RetuenAnnotationCalloutAccessoryTapFromMapView:self withMarker:marker];
	}
}

- (void)mapViewDidFinishLoadingMap:(MKMapView *)mapView
{
	if(self.delegate &&[(NSObject*)self.delegate respondsToSelector:@selector(MapLoadFinishFromMapView)])
	{
		[self.delegate MapLoadFinishFromMapView];
	}
}
- (void)mapViewDidFailLoadingMap:(MKMapView *)mapView withError:(NSError *)error
{
	if(self.delegate &&[(NSObject*)self.delegate respondsToSelector:@selector(MapLoadFailedFromMapView)])
	{
		[self.delegate MapLoadFailedFromMapView];
	}
}


-(void)OKtoShowMyLocation
{
	_map.showsUserLocation = YES;
}

-(void)SetMyLocation:(Marker*)userMarker
{
	if(userMarker == nil) return;
	
	if(_userMarker && _userMarker.longitude == userMarker.longitude && _userMarker.latitude == userMarker.latitude){
		return;
	}
	
	self._userMarker = userMarker;
}
-(void)ShowMyLocation
{
	[self MoveMapToLocation:_userMarker.latitude withLng:_userMarker.longitude];
	//[self MoveMapToLocationByDelta:_userMarker.latitude withLng:_userMarker.longitude delta:0.05];
	
	//_map.showsUserLocation=YES;
	
	//NSLog(@"%f,%f", _userMarker.latitude, _userMarker.longitude);
	
	[_map selectAnnotation:_map.userLocation animated:YES];
	
}
-(void)AddMarkers:(NSArray*)markerArray
{
	if(markerArray == nil || [markerArray count] == 0) return;
	
	self._markerArray = markerArray;
	
	[_map addAnnotations:_markerArray];
	
}
-(void)RemoveAllMarkers
{
	NSMutableArray *curAnnos = [[NSMutableArray alloc] initWithArray:_map.annotations];
	[curAnnos removeObject:_map.userLocation];
	[_map removeAnnotations:curAnnos];
	
}
-(void)ShowPoiPopUpByID:(NSString*)poiID
{
	Marker *showMarkertmp = nil;
	for(int i=0; i<[_markerArray count]; i++)
	{
		Marker *marker = [_markerArray objectAtIndex:i];
		if([marker.dataIndex compare:poiID] == NSOrderedSame)
		{
			showMarkertmp = marker;
			break;
		}
	}
	
	if(showMarkertmp == nil) return;
	
	[self MoveMapToLocation:showMarkertmp.latitude withLng:showMarkertmp.longitude];
	[_map selectAnnotation:showMarkertmp animated:YES];
}
-(void)SetMarkerArray:(NSArray*)markerArray
{
	self._markerArray = markerArray;
}


- (CLLocationCoordinate2D) getlatLngWithPoint:(CGPoint)pt{
    
    CLLocationCoordinate2D coord = [_map convertPoint:pt toCoordinateFromView:self];
    
    return coord;
}


- (void)dealloc {

}





@end
