//
//  JingDianMapCell.h
//  IYLM
//
//  Created by Jian-Ye on 12-11-8.
//  Copyright (c) 2012年 Jian-Ye. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RRStyleLabel.h"


@interface JingDianMapCell : UIView
{
   IBOutlet UIImageView *leftImageView;
 
   IBOutlet UILabel         *titleL;
   IBOutlet UILabel         *subTitle;
   IBOutlet UILabel        *rule;
   IBOutlet UILabel        *rule1;
}

- (void) fillData:(id)data;

@end
