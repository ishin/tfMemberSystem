//
//  JingDianMapCell.m
//  IYLM
//
//  Created by Jian-Ye on 12-11-8.
//  Copyright (c) 2012年 Jian-Ye. All rights reserved.
//

#import "JingDianMapCell.h"
#import "UIImageView+WebCache.h"
#import "UILabel+ContentSize.h"


@interface JingDianMapCell ()
{
    RRStyleLabel* rule_g;
}

@end

@implementation JingDianMapCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        
    }
    return self;
}



- (void) fillData:(id)data{
 
    
    titleL.font = [UIFont boldSystemFontOfSize:14];
    titleL.textColor = [UIColor blackColor];
    titleL.userInteractionEnabled = NO;
    titleL.backgroundColor = [UIColor clearColor];
    //titleL.adjustsFontSizeToFitWidth =
    titleL.text = [data objectForKey:@"title"];
    
    CGRect rc = subTitle.frame;
    rc.size.width = self.frame.size.width - rc.origin.x - 10;
    subTitle.frame = rc;
    
    subTitle.font = [UIFont systemFontOfSize:12];
    subTitle.textColor = COLOR_TEXT_A;
    
    subTitle.text = [data objectForKey:@"subtitle"];
    [subTitle contentSize];
   
   
    leftImageView.image = [data objectForKey:@"image"];
    leftImageView.layer.cornerRadius = 3;
    leftImageView.clipsToBounds = YES;
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
