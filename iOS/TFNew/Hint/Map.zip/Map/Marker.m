//
//  Marker.m
//  CakeLove
//
//  Created by radar on 10-2-26.
//  Copyright 2010 RED/SAFI. All rights reserved.
//

#import "Marker.h"


@implementation Marker

@synthesize latitude;
@synthesize longitude;
@synthesize title;
@synthesize subtitle;
@synthesize leftImage;
@synthesize annImage;
@synthesize dataIndex;
@synthesize pinAnColor;


- (CLLocationCoordinate2D)coordinate
{
	CLLocationCoordinate2D coord = {self.latitude, self.longitude};
	return coord;
}

- (void)dealloc {
	
}

@end
