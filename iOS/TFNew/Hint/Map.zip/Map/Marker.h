//
//  Marker.h
//  CakeLove
//
//  Created by radar on 10-2-26.
//  Copyright 2010 RED/SAFI. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
#import <MapKit/MKAnnotation.h>


@interface Marker : NSObject <MKAnnotation>{
	double latitude;
	double longitude;
	
	MKPinAnnotationColor pinAnColor;
}
@property (nonatomic) double latitude;
@property (nonatomic) double longitude;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subtitle;
@property (nonatomic, strong) UIImage *leftImage;
@property (nonatomic, strong) UIImage *annImage;
@property (nonatomic, strong) NSString *dataIndex;
@property (nonatomic) MKPinAnnotationColor pinAnColor;

@property (nonatomic, readonly) CLLocationCoordinate2D coordinate;

@end
