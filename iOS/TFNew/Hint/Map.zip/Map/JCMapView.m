//
//  JCMapView.m
//  
//
//  Created by Jian-Ye on 12-10-16.
//  Copyright (c) 2012年 Jian-Ye. All rights reserved.
//

#import "JCMapView.h"
#import "CallOutAnnotationVifew.h"
#import "JingDianMapCell.h"
#define default_span 40000

@interface JCMapView ()
{
    NSMutableArray *_annotationList;
    
    CalloutMapAnnotation *_calloutAnnotation;
	CalloutMapAnnotation *_previousdAnnotation;
    
}
-(void)setAnnotionsWithList:(NSArray *)list;

@end

@implementation JCMapView

@synthesize mapView=_mapView;
@synthesize markers;
@synthesize delegate;


- (id) initWithFrame:(CGRect)frame
{
    
    self = [super initWithFrame:frame];
    
     _annotationList = [[NSMutableArray alloc] init];
    
    _mapView = [[MKMapView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
    [_mapView setMapType: MKMapTypeStandard];
    [_mapView setDelegate:self];
    
    
    
    [self addSubview:_mapView];
    
    return self;
    
}

- (void) locateMe{
    _mapView.showsUserLocation = YES;
}

-(void)setAnnotionsWithList:(NSArray *)list
{
    self.markers = [NSMutableArray arrayWithArray:list];
    
    for (int i = 0;i<[list count];i++) {
        NSDictionary *dic = [list objectAtIndex:i];
        CLLocationDegrees latitude=[[dic objectForKey:@"latitude"] doubleValue];
        CLLocationDegrees longitude=[[dic objectForKey:@"longitude"] doubleValue];
        CLLocationCoordinate2D location=CLLocationCoordinate2DMake(latitude, longitude);
        
        MKCoordinateRegion region=MKCoordinateRegionMakeWithDistance(location,default_span ,default_span );
        MKCoordinateRegion adjustedRegion = [_mapView regionThatFits:region];
        [_mapView setRegion:adjustedRegion animated:YES];
        
        BasicMapAnnotation *  annotation=[[BasicMapAnnotation alloc] initWithLatitude:latitude andLongitude:longitude];
        annotation.tag = i;
        [_mapView addAnnotation:annotation];
        
        [_annotationList addObject:annotation];
        
        
    }
    
}

- (void) showCity:(NSDictionary *)city
{
    CLLocationDegrees latitude=[[city objectForKey:@"latitude"] doubleValue];
    CLLocationDegrees longitude=[[city objectForKey:@"longitude"] doubleValue];
    CLLocationCoordinate2D location=CLLocationCoordinate2DMake(latitude, longitude);
    
    MKCoordinateRegion region=MKCoordinateRegionMakeWithDistance(location,default_span ,default_span );
    MKCoordinateRegion adjustedRegion = [_mapView regionThatFits:region];
    [_mapView setRegion:adjustedRegion animated:YES];
    
}

- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view {
	if ([view.annotation isKindOfClass:[BasicMapAnnotation class]]) {
        if (_calloutAnnotation.coordinate.latitude == view.annotation.coordinate.latitude&&
            _calloutAnnotation.coordinate.longitude == view.annotation.coordinate.longitude) {
            return;
        }
        if (_calloutAnnotation) {
            [mapView removeAnnotation:_calloutAnnotation];
            _calloutAnnotation = nil;
        }
        _calloutAnnotation = [[CalloutMapAnnotation alloc]
                               initWithLatitude:view.annotation.coordinate.latitude
                               andLongitude:view.annotation.coordinate.longitude];
        _calloutAnnotation.tag = [(BasicMapAnnotation *)view.annotation tag];
        [mapView addAnnotation:_calloutAnnotation];
        
        [mapView setCenterCoordinate:_calloutAnnotation.coordinate animated:YES];
	}
   
}

- (void)mapView:(MKMapView *)mapView didDeselectAnnotationView:(MKAnnotationView *)view {
    if (_calloutAnnotation&& ![view isKindOfClass:[CallOutAnnotationVifew class]]) {
        if (_calloutAnnotation.coordinate.latitude == view.annotation.coordinate.latitude&&
            _calloutAnnotation.coordinate.longitude == view.annotation.coordinate.longitude) {
            [mapView removeAnnotation:_calloutAnnotation];
            _calloutAnnotation = nil;
        }
    }
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation {
	if ([annotation isKindOfClass:[CalloutMapAnnotation class]]) {

        int tag = (int)[(CalloutMapAnnotation *)annotation tag];
        
        CallOutAnnotationVifew *annotationView = (CallOutAnnotationVifew *)[mapView dequeueReusableAnnotationViewWithIdentifier:@"CalloutView"];
        if (!annotationView) {
            annotationView = [[CallOutAnnotationVifew alloc] initWithAnnotation:annotation reuseIdentifier:@"CalloutView"];
            
            JingDianMapCell  *cell = [[[NSBundle mainBundle] loadNibNamed:@"JingDianMapCell" owner:self options:nil] objectAtIndex:0];
            
            [cell fillData:[markers objectAtIndex:tag]];
            
            [annotationView.contentView addSubview:cell];
            cell.tag = 100;
            
        }
        else
        {
            JingDianMapCell  *cell = (JingDianMapCell*)[annotationView.contentView viewWithTag:100];
            [cell fillData:[markers objectAtIndex:tag]];
        }
        annotationView.tag = tag;
        
        return annotationView;
	} else if ([annotation isKindOfClass:[BasicMapAnnotation class]]) {
        
         MKAnnotationView *annotationView =[self.mapView dequeueReusableAnnotationViewWithIdentifier:@"CustomAnnotation"];
        if (!annotationView) {
            annotationView = [[MKAnnotationView alloc] initWithAnnotation:annotation
                                                           reuseIdentifier:@"CustomAnnotation"];
            annotationView.canShowCallout = NO;
            annotationView.image = [UIImage imageNamed:@"map_poi_icon.png"];
        }
		
		return annotationView;
    }
    else if(annotation == mapView.userLocation)
	{
		if(mapView.userLocation.location){
			float latitude = mapView.userLocation.location.coordinate.latitude;
			float longitude = mapView.userLocation.location.coordinate.longitude;
			
			CLLocationCoordinate2D location=CLLocationCoordinate2DMake(latitude, longitude);
            
            MKCoordinateRegion region=MKCoordinateRegionMakeWithDistance(location,default_span ,default_span );
            MKCoordinateRegion adjustedRegion = [_mapView regionThatFits:region];
            [_mapView setRegion:adjustedRegion animated:YES];
		}
		return nil;
	}
	return nil;
}
- (void)resetAnnitations:(NSArray *)data
{
    [_annotationList removeAllObjects];
    [self setAnnotionsWithList:data];
}

-(void)ShowPoiPopUpByID:(int)index
{
    
    BasicMapAnnotation *showMarker = [_annotationList objectAtIndex:index];
    
    [self MoveMapToLocation:showMarker.coordinate.latitude withLng:showMarker.coordinate.longitude];
    
    
    [_mapView selectAnnotation:showMarker animated:YES];
}

-(void)MoveMapToLocation:(double)latitude withLng:(double)longitude
{
    @try {
        CLLocationCoordinate2D theCenter;
        theCenter.latitude = latitude;
        theCenter.longitude = longitude;
        
        
        MKCoordinateSpan theSpan;
        theSpan.latitudeDelta = 0.02;
        theSpan.longitudeDelta = 0.02;
        
        MKCoordinateRegion theRegin;
        theRegin.center = theCenter;
        theRegin.span = theSpan;
        
        [_mapView setRegion:theRegin];
        [_mapView regionThatFits:theRegin];
        
        [_mapView setCenterCoordinate:theCenter animated:YES];
    }
    @catch (NSException *exception) {
        ;
    }
    @finally {
        ;
    }
}


@end
