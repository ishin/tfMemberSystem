//
//  LMapView.h
//  CakeLove
//
//  Created by radar on 10-2-26.
//  Copyright 2010 RED/SAFI. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <MapKit/MapKit.h>
#import <MapKit/MKMapView.h>
#import <MapKit/MKAnnotation.h>
#import <MapKit/MKAnnotationView.h>
#import <CoreLocation/CoreLocation.h>
#import "Marker.h"

@class LMapView;
@protocol MapDelegate <NSObject>
@optional
-(void)MapLoadFinishFromMapView;
-(void)MapLoadFailedFromMapView;
-(void)RetuenAnnotationCalloutAccessoryTapFromMapView:(LMapView*)lmapview withMarker:(Marker*)marker;
- (void)updateMyLocation:(float)longitude latitude:(float)latitude;
@end


@interface LMapView : UIView <MKMapViewDelegate> {

	MKMapView *_map;
	NSArray *_markerArray;
	Marker *_userMarker;
	
	BOOL needShowAccessView;
	
	
}

@property(weak, nonatomic) id <MapDelegate> delegate;
@property (nonatomic, strong) Marker *_userMarker;
@property (nonatomic, strong) NSArray *_markerArray;
@property (nonatomic) BOOL needShowAccessView;
@property (nonatomic, readonly) MKMapView *_map;


-(void)MoveMapToLocation:(double)latitude withLng:(double)longitude;
-(void)MoveMapToLocationBySpan:(double)latitude withLng:(double)longitude bySpan:(MKCoordinateSpan)theSpan;
-(void)MoveMapToLocationByDelta:(double)latitude withLng:(double)longitude delta:(double)delta;

-(void)SetMyLocation:(Marker*)userMarker;
-(void)ShowMyLocation; 
-(void)AddMarkers:(NSArray*)markerArray;
-(void)RemoveAllMarkers; 
-(void)ShowPoiPopUpByID:(NSString*)poiID;
-(void)SetMarkerArray:(NSArray*)markerArray;

-(void)OKtoShowMyLocation;

- (CLLocationCoordinate2D) getlatLngWithPoint:(CGPoint)pt;


@end
