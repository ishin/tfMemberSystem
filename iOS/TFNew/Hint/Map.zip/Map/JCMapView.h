




#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

#import "CalloutMapAnnotation.h"
#import "BasicMapAnnotation.h"

@protocol JCMapViewDelegate;
@interface JCMapView : UIView<MKMapViewDelegate>
{
    
}
@property(nonatomic,strong) MKMapView *mapView;

@property(nonatomic,assign)id<JCMapViewDelegate> delegate;
@property(nonatomic, strong) NSMutableArray *markers;

- (void)resetAnnitations:(NSArray *)data;
- (void) showCity:(NSDictionary*)city;

- (void) locateMe;

-(void)ShowPoiPopUpByID:(int)index;
@end

@protocol JCMapViewDelegate <NSObject>

@optional
- (void)customMKMapViewDidSelectedWithInfo:(id)info;

@end